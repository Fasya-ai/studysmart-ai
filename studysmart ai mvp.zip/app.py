import streamlit as st
from ai_core import ai_ders_cevabi, save_response
from student_panel import student_main
from teacher_panel import teacher_main

def main():
    st.title("📘 StudySmart AI - Öğrenci Paneli")
    
    konu = st.text_input("📚 Hangi konuyu öğrenmek istiyorsun?")
    
    if konu:
        if st.button("🎓 Anlat!"):
            with st.spinner("AI konuyu işliyor..."):
                cevap = ai_ders_cevabi(konu)
                st.success("✅ AI tarafından oluşturulan konu anlatımı:")
                st.markdown(cevap)

                # Kaydet
                def save_response(konu, cevap):
                    yeni_veri = {"konu": konu, "cevap": cevap}
    ...

    
run_student_app = main

def run_student_app():
    student_main()

def run_teacher_app():
    teacher_main()
