import google.generativeai as genai

genai.configure(api_key="AIzaSyBq-p620k0L-L223GkxnoKJ9c56rbUe0LQ")

model = genai.GenerativeModel(model_name="gemini-2.0-flash")

def ai_ders_cevabi(konu):
    response = model.generate_content(
        f"{konu} konusunu YKS'ye hazırlanan 17 yaşında bir öğrenciye, anlaşılır, kısa ve örnekli şekilde anlat.")
    return response.text

import json
from datetime import datetime

def save_response(konu, cevap):
    yeni_kayit = {
        "konu": konu,
        "cevap": cevap,
        "teacher_approved": False,
        "timestamp": datetime.now().isoformat()
    }

    try:
        with open("pending.json", "r", encoding="utf-8") as f:
            veriler = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        veriler = []

    # ✅ Var olan listeye ekle
    veriler.append(yeni_kayit)

    # ✅ Üzerine yazmadan kaydet
    with open("pending.json", "w", encoding="utf-8") as f:
        json.dump(veriler, f, ensure_ascii=False, indent=2)

