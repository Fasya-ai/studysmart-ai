import streamlit as st
import json

def teacher_main():
    st.title("👩‍🏫 Öğretmen Paneli")

    try:
        with open("pending.json", "r", encoding="utf-8") as file:
            veriler = json.load(file)
    except FileNotFoundError:
        st.warning("Henüz öğrenci tarafından gönderilen bir içerik bulunamadı.")
        return

    if not veriler:
        st.info("Onay bekleyen içerik yok.")
        return

    for i, item in enumerate(veriler):
        konu = item.get("konu", "Konu belirtilmemiş")
        cevap = item.get("cevap", "Bu konu için henüz AI cevabı oluşturulmamış.")
        
        st.subheader(f"{i+1}. Konu: {konu}")
        st.markdown("**AI Cevabı:**")
        st.write(cevap)

        if st.button("✅ Onayla", key=f"ok_{i}"):
            veriler[i]["teacher_approved"] = True
            with open("pending.json", "w", encoding="utf-8") as f:
                json.dump(veriler, f, ensure_ascii=False, indent=2)
            st.success(f"{konu} onaylandı!")
        
        if st.button("✏️ Yeniden Yaz", key=f"edit_{i}"):
            st.info("AI içeriği yeniden yazması önerildi.")
