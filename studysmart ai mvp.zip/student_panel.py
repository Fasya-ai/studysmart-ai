import streamlit as st
from ai_core import ai_ders_cevabi, save_response
import json

def student_main():
    import json
    st.title("📚 StudySmart AI - Öğrenci Paneli")

    konu = st.text_input("📘 Hangi konuyu öğrenmek istiyorsun?")
    if st.button("🔍 Anlat"):
        if konu:
            with st.spinner("AI konuyu anlatıyor..."):
                try:
                    cevap = ai_ders_cevabi(konu)
                    st.success("Konu öğretmene iletildi, onay bekleniyor.")
                    save_response(konu, cevap)
                except Exception as e:
                    st.error(f"Bir hata oluştu: {e}")
        else:
            st.warning("Lütfen bir konu girin.")

    # 📌 Onaylanmış cevapları göster
    try:
        with open("pending.json", "r", encoding="utf-8") as f:
            veriler = json.load(f)
            onayli = [v for v in veriler if v.get("teacher_approved")]
            if onayli:
                st.markdown("## ✅ Onaylanmış Konular")
                for v in onayli:
                    st.subheader(v["konu"])
                    st.write(v["cevap"])
            else:
                st.info("Henüz onaylanmış bir konu yok.")
    except FileNotFoundError:
        pass

