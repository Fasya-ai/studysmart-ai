# StudySmart AI - MVP

StudySmart AI, öğrencilerin istediği konuyu yapay zeka ile öğrenebildiği, ancak cevapların öğrenciye gösterilmeden önce öğretmen onayına sunulduğu etkileşimli bir eğitim platformudur.

## Özellikler
- Öğrenciler istediği konuyu girer.
- Google Gemini API kullanılarak kısa ve örnekli konu anlatımı oluşturulur.
- Oluşturulan yanıtlar öğretmen onayına iletilir.
- Öğretmen onayından sonra öğrenci yanıtı görebilir.
- Basit ve kullanıcı dostu arayüz (Streamlit).

## Kullanılan Teknolojiler
- Python 3
- Streamlit
- Google Gemini API (`google-generativeai`)
- JSON veri depolama

## Kurulum
1. Gerekli kütüphaneleri yükleyin:
```bash
pip install -r requirements.txt

## Uygulamayı başlatın:
bash
streamlit run main.py

Bu proje özel mülkiyettir. Kodlar ve fikir telif hakkı ile korunmaktadır.
İzinsiz kopyalanamaz, dağıtılamaz veya ticari amaçla kullanılamaz.
Kullanım için proje sahibinden yazılı izin alınması zorunludur.

© 2025 [Asya ASI]. Tüm hakları saklıdır.