import streamlit as st
from app import run_student_app, run_teacher_app

st.set_page_config(page_title="StudySmart AI", layout="centered")

st.title("📘 StudySmart AI")
st.markdown("Yapay zeka destekli etkileşimli ders platformu")

# Kullanıcı adı al
username = st.text_input("Adınızı girin:")

# Rol seçimi
role = st.radio("Rolünüzü seçin:", ["Öğrenci", "Öğretmen"])

# Session state’e kaydet
if username:
    st.session_state["username"] = username
    if role == "Öğrenci":
        run_student_app()
    elif role == "Öğretmen":
        run_teacher_app()
